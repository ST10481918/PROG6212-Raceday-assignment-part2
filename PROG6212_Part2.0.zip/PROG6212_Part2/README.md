# RaceDay API – PROG6212 POE Part 2

ASP.NET Core 8 Web API that powers the RaceDay system (events, categories, enrolments, results),
built from the Part 1 endpoint plan. Uses Entity Framework Core (Code-First) with SQL Server,
JWT authentication, role-based access, Swagger and an xUnit test suite run by GitHub Actions.

![CI](https://github.com/<your-username>/<your-repo>/actions/workflows/ci.yml/badge.svg)

## CI/CD screenshot
> Replace this line with a screenshot of a successful green GitHub Actions run:
> `![Green build](docs/green-build.png)`

## YouTube demo
> Add your unlisted YouTube link here: https://youtu.be/xxxxxxxx

## Setup and run
Requirements: .NET 8 SDK, SQL Server or LocalDB (installed with Visual Studio), `dotnet-ef` tool.

```bash
dotnet tool install --global dotnet-ef

# 1. Check the connection string in RaceDay.Api/appsettings.json
# 2. Create the first migration (once)
cd RaceDay.Api
dotnet ef migrations add InitialCreate

# 3. Run the API (the database is created/updated automatically on start-up)
dotnet run
```

Open `https://localhost:<port>/swagger`. Log in through `/api/auth/login`, click **Authorize**
and paste the token to try the protected endpoints.

Run the tests: `dotnet test RaceDay.sln`

## The two roles
| Role | What they can do |
|---|---|
| **Organiser** | Create, update and delete **their own** events; define categories for their events; view all enrolments for their events; capture finish times and positions; view their profile |
| **Participant** | View events, categories and leaderboards; enrol in an event by choosing a category (gets a bib number); withdraw; view their own enrolments and results; view/update their profile |

* **How registration is managed:** anyone can register as a Participant. Registering as an Organiser
  needs a secret `organiserCode` (`Registration:OrganiserCode` in appsettings), so users cannot simply
  pick the Organiser role.
* **Passwords** are hashed with PBKDF2-SHA256 and a random salt. The plain password is never stored.
* **Session management:** login returns a signed JWT (as in the Part 1 plan). The token carries the user's id and role
  and must be sent as `Authorization: Bearer <token>` on every protected request.
* Endpoints for Guests (no token): register, login, `GET /api/events`, `GET /api/events/{id}`, `GET /api/events/{id}/results`.

## Endpoints
| Method | Route | Role |
|---|---|---|
| POST | `/api/auth/register` | Guest |
| POST | `/api/auth/login` | Guest |
| GET / PUT | `/api/users/profile` | Any logged-in user |
| GET | `/api/events`, `/api/events/{id}` | Guest / any |
| POST / PUT / DELETE | `/api/events`, `/api/events/{id}` | Organiser (owner) |
| GET | `/api/categories`, `/api/events/{id}/categories` | Any logged-in user |
| POST | `/api/events/{id}/categories` | Organiser (owner) |
| DELETE | `/api/categories/{id}` | Organiser (owner) |
| POST / DELETE | `/api/events/{id}/enrol` | Participant |
| GET | `/api/enrolments/me` | Participant |
| GET | `/api/events/{id}/enrolments` | Organiser (owner) |
| GET | `/api/events/{id}/results` | Guest / any |
| POST | `/api/events/{id}/results` | Organiser (owner) |
| GET | `/api/results/me` | Participant |

## Project structure
```
RaceDay.Api/     Controllers, Models, DTOs, Data (DbContext), Services (JWT + password hashing), Program.cs
RaceDay.Tests/   xUnit tests (controller unit tests, role-attribute tests, full HTTP integration tests)
.github/workflows/ci.yml   Builds and runs all tests on every push
```

## Differences from the Part 1 design (update your ERD/SQL to match)
Part 1 only had IDs and names, so the schema had to be extended to support login and the Part 2 requirements:
* `Participants` + `Organizers` are merged into one **Users** table with a `Role` column, `Email` and `PasswordHash`.
* **Events** now has Name, Description, Date, Location, DistanceKm, Type (Run/Walk/Cycle) and an OrganiserId (it no longer holds the participant).
* **Categories** belong to an event.
* **Enrolments** (new) link User + Event + Category and hold the BibNumber.
* **Results** (new, replaces Event_results) store FinishTime and Position per enrolment.
* `Route` and `Performance_History` from Part 1 are not used by the Part 2 endpoints. Performance history can be read from Results.

## Testing
The suite covers registration/login, password hashing, token contents, profile, events, categories, enrolments,
results, and role rules (success and failure cases). `ApiIntegrationTests` starts the real API so 401 (no token)
and 403 (wrong role) are checked through the real authentication pipeline.
