using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

/// <summary>Boots the real API (real JWT middleware and role checks) on an in-memory database.</summary>
public class ApiFactory : WebApplicationFactory<Program>
{
    private readonly string _dbName = Guid.NewGuid().ToString();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureServices(services =>
        {
            var descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
            if (descriptor != null) services.Remove(descriptor);
            services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(_dbName));
        });
    }
}

public class ApiIntegrationTests : IClassFixture<ApiFactory>
{
    // Must match Registration:OrganiserCode in RaceDay.Api/appsettings.json
    private const string OrganiserCode = "RACEDAY-ORGANISER-2026";
    private const string Password = "Password123!";

    private readonly ApiFactory _factory;

    public ApiIntegrationTests(ApiFactory factory) => _factory = factory;

    private async Task<HttpClient> LoggedInClient(string role)
    {
        var client = _factory.CreateClient();
        var email = $"{Guid.NewGuid():N}@test.com";

        var register = await client.PostAsJsonAsync("/api/auth/register", new
        {
            name = "Test",
            surname = "User",
            email,
            password = Password,
            role,
            organiserCode = role == "Organiser" ? OrganiserCode : null
        });
        Assert.Equal(HttpStatusCode.Created, register.StatusCode);

        var login = await client.PostAsJsonAsync("/api/auth/login", new { email, password = Password });
        Assert.Equal(HttpStatusCode.OK, login.StatusCode);
        var body = await login.Content.ReadFromJsonAsync<LoginResponse>();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", body!.Token);
        return client;
    }

    private static object NewEvent() => new
    {
        name = "Integration 5km",
        description = "Created by a test",
        date = DateTime.UtcNow.AddDays(30),
        location = "Pretoria",
        distanceKm = 5,
        type = "Run"
    };

    private static async Task<int> ReadId(HttpResponseMessage response)
    {
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("id").GetInt32();
    }

    // ---------- Unauthenticated requests are rejected ----------

    [Theory]
    [InlineData("/api/users/profile")]
    [InlineData("/api/categories")]
    [InlineData("/api/enrolments/me")]
    [InlineData("/api/results/me")]
    public async Task ProtectedGetEndpoints_WithoutToken_Return401(string url)
    {
        var response = await _factory.CreateClient().GetAsync(url);
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_WithoutToken_Returns401()
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/events", NewEvent());
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task InvalidToken_Returns401()
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "not.a.real.token");

        var response = await client.GetAsync("/api/users/profile");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    // ---------- Public endpoints work without a token ----------

    [Fact]
    public async Task GetEvents_WithoutToken_Returns200()
    {
        var response = await _factory.CreateClient().GetAsync("/api/events");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    // ---------- Registration and login over HTTP ----------

    [Fact]
    public async Task Login_WithWrongPassword_Returns401()
    {
        var client = _factory.CreateClient();
        var email = $"{Guid.NewGuid():N}@test.com";
        await client.PostAsJsonAsync("/api/auth/register", new { name = "A", surname = "B", email, password = Password, role = "Participant" });

        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword1!" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Register_WithInvalidEmail_Returns400()
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/auth/register",
            new { name = "A", surname = "B", email = "not-an-email", password = Password, role = "Participant" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_WithShortPassword_Returns400()
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/auth/register",
            new { name = "A", surname = "B", email = $"{Guid.NewGuid():N}@test.com", password = "short", role = "Participant" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_AsOrganiser_WithoutCode_Returns403()
    {
        var response = await _factory.CreateClient().PostAsJsonAsync("/api/auth/register",
            new { name = "A", surname = "B", email = $"{Guid.NewGuid():N}@test.com", password = Password, role = "Organiser" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task LoggedInUser_CanViewTheirProfile(string role)
    {
        var client = await LoggedInClient(role);

        var response = await client.GetAsync("/api/users/profile");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var profile = await response.Content.ReadFromJsonAsync<ProfileResponse>();
        Assert.Equal(role, profile!.Role);
    }

    // ---------- Role-based access is enforced ----------

    [Fact]
    public async Task Participant_CannotCreateEvent_Returns403()
    {
        var client = await LoggedInClient("Participant");

        var response = await client.PostAsJsonAsync("/api/events", NewEvent());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanCreateEvent_Returns201()
    {
        var client = await LoggedInClient("Organiser");

        var response = await client.PostAsJsonAsync("/api/events", NewEvent());

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotDeleteEvent_Returns403()
    {
        var organiser = await LoggedInClient("Organiser");
        var id = await ReadId(await organiser.PostAsJsonAsync("/api/events", NewEvent()));
        var participant = await LoggedInClient("Participant");

        var response = await participant.DeleteAsync($"/api/events/{id}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnrolInAnEvent_Returns403()
    {
        var organiser = await LoggedInClient("Organiser");
        var id = await ReadId(await organiser.PostAsJsonAsync("/api/events", NewEvent()));

        var response = await organiser.PostAsJsonAsync($"/api/events/{id}/enrol", new { categoryId = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewEnrolmentsForAnEvent_Returns403()
    {
        var organiser = await LoggedInClient("Organiser");
        var id = await ReadId(await organiser.PostAsJsonAsync("/api/events", NewEvent()));
        var participant = await LoggedInClient("Participant");

        var response = await participant.GetAsync($"/api/events/{id}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotRecordResults_Returns403()
    {
        var organiser = await LoggedInClient("Organiser");
        var id = await ReadId(await organiser.PostAsJsonAsync("/api/events", NewEvent()));
        var participant = await LoggedInClient("Participant");

        var response = await participant.PostAsJsonAsync($"/api/events/{id}/results",
            new { bibNumber = 1001, finishTime = "01:00:00", position = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    // ---------- Full happy path over HTTP ----------

    [Fact]
    public async Task FullFlow_OrganiserCreatesEvent_ParticipantEnrols_OrganiserRecordsResult_ParticipantSeesIt()
    {
        var organiser = await LoggedInClient("Organiser");
        var participant = await LoggedInClient("Participant");

        var eventId = await ReadId(await organiser.PostAsJsonAsync("/api/events", NewEvent()));
        var categoryResponse = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories", new { name = "Senior" });
        Assert.Equal(HttpStatusCode.Created, categoryResponse.StatusCode);
        var categoryId = await ReadId(categoryResponse);

        var enrol = await participant.PostAsJsonAsync($"/api/events/{eventId}/enrol", new { categoryId });
        Assert.Equal(HttpStatusCode.Created, enrol.StatusCode);
        var enrolBody = await enrol.Content.ReadFromJsonAsync<EnrolResponse>();
        Assert.Equal(1001, enrolBody!.BibNumber);

        var enrolments = await organiser.GetFromJsonAsync<List<EnrolmentResponse>>($"/api/events/{eventId}/enrolments");
        Assert.Single(enrolments!);

        var record = await organiser.PostAsJsonAsync($"/api/events/{eventId}/results",
            new { bibNumber = 1001, finishTime = "00:42:10", position = 1 });
        Assert.Equal(HttpStatusCode.Created, record.StatusCode);

        var mine = await participant.GetFromJsonAsync<List<ResultResponse>>("/api/results/me");
        Assert.Single(mine!);
        Assert.Equal(1, mine![0].Position);
        Assert.Equal(new TimeSpan(0, 42, 10), mine[0].FinishTime);
    }
}
