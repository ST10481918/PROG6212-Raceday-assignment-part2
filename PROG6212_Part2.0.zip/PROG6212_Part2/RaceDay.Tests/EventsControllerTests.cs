using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

public class EventsControllerTests
{
    private static EventRequest NewRequest(string name = "City 10km") => new()
    {
        Name = name,
        Description = "Fun run",
        Date = DateTime.UtcNow.AddDays(20),
        Location = "Sandton",
        DistanceKm = 10,
        Type = EventType.Run
    };

    [Fact]
    public async Task Create_AsOrganiser_Returns201_AndOrganiserOwnsTheEvent()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Create(NewRequest());

        var created = Assert.IsType<CreatedAtActionResult>(result.Result);
        var body = Assert.IsType<EventResponse>(created.Value);
        Assert.Equal(org.Id, body.OrganiserId);
        Assert.Equal(1, await db.Events.CountAsync());
    }

    [Theory]
    [InlineData(EventType.Run)]
    [InlineData(EventType.Walk)]
    [InlineData(EventType.Cycle)]
    public async Task Create_StoresAllThreeEventTypes(EventType type)
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);
        var request = NewRequest();
        request.Type = type;

        await controller.Create(request);

        Assert.Equal(type, (await db.Events.SingleAsync()).Type);
    }

    [Fact]
    public async Task Create_SavesNameDescriptionDateLocationAndDistance()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);
        var request = NewRequest("Soweto Marathon");
        request.DistanceKm = 42.2;

        await controller.Create(request);

        var saved = await db.Events.SingleAsync();
        Assert.Equal("Soweto Marathon", saved.Name);
        Assert.Equal("Fun run", saved.Description);
        Assert.Equal("Sandton", saved.Location);
        Assert.Equal(42.2, saved.DistanceKm);
    }

    [Fact]
    public async Task GetAll_ReturnsEvents_SoonestFirst()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        await TestHelpers.AddEvent(db, org.Id, daysFromNow: 50);
        var soon = await TestHelpers.AddEvent(db, org.Id, daysFromNow: 5);

        var result = await new EventsController(db).GetAll();

        var list = Assert.IsAssignableFrom<IEnumerable<EventResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value).ToList();
        Assert.Equal(2, list.Count);
        Assert.Equal(soon.Id, list[0].Id);
    }

    [Fact]
    public async Task GetById_UnknownId_Returns404()
    {
        using var db = TestHelpers.NewDb();

        var result = await new EventsController(db).GetById(999);

        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetById_ExistingId_ReturnsEvent()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);

        var result = await new EventsController(db).GetById(ev.Id);

        var body = Assert.IsType<EventResponse>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.Equal(ev.Id, body.Id);
    }

    [Fact]
    public async Task Update_OwnEvent_ChangesTheEvent()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Update(ev.Id, NewRequest("Renamed"));

        Assert.IsType<OkObjectResult>(result.Result);
        Assert.Equal("Renamed", (await db.Events.FindAsync(ev.Id))!.Name);
    }

    [Fact]
    public async Task Update_AnotherOrganisersEvent_IsForbidden_AndNothingChanges()
    {
        using var db = TestHelpers.NewDb();
        var owner = await TestHelpers.AddUser(db, UserRole.Organiser);
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, owner.Id);
        var controller = new EventsController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.Update(ev.Id, NewRequest("Hacked"));

        Assert.IsType<ForbidResult>(result.Result);
        Assert.Equal("Test 10km", (await db.Events.FindAsync(ev.Id))!.Name);
    }

    [Fact]
    public async Task Update_UnknownEvent_Returns404()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Update(999, NewRequest());

        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task Delete_OwnEvent_RemovesIt()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Delete(ev.Id);

        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(db.Events);
    }

    [Fact]
    public async Task Delete_AnotherOrganisersEvent_IsForbidden_AndEventSurvives()
    {
        using var db = TestHelpers.NewDb();
        var owner = await TestHelpers.AddUser(db, UserRole.Organiser);
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, owner.Id);
        var controller = new EventsController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.Delete(ev.Id);

        Assert.IsType<ForbidResult>(result);
        Assert.Equal(1, await db.Events.CountAsync());
    }

    [Fact]
    public async Task Delete_UnknownEvent_Returns404()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db).WithUser(org.Id, UserRole.Organiser);

        Assert.IsType<NotFoundObjectResult>(await controller.Delete(999));
    }
}
