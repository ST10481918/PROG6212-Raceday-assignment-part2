using RaceDay.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

public class ResultsControllerTests
{
    private static async Task<(AppDbContext Db, User Organiser, User Runner, Event Event, Enrolment Enrolment)> Arrange()
    {
        var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var enrolment = await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id, 1001);
        return (db, org, runner, ev, enrolment);
    }

    private static RecordResultRequest Req(int bib = 1001, string time = "02:45:12", int position = 1) => new()
    {
        BibNumber = bib,
        FinishTime = TimeSpan.Parse(time),
        Position = position
    };

    [Fact]
    public async Task Record_OwningOrganiser_SavesFinishTimeAndPosition()
    {
        var (db, org, _, ev, enrolment) = await Arrange();
        using var _db = db;
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Record(ev.Id, Req());

        Assert.Equal(201, Assert.IsType<ObjectResult>(result).StatusCode);
        var saved = await db.Results.SingleAsync();
        Assert.Equal(enrolment.Id, saved.EnrolmentId);
        Assert.Equal(new TimeSpan(2, 45, 12), saved.FinishTime);
        Assert.Equal(1, saved.Position);
    }

    [Fact]
    public async Task Record_OtherOrganiser_IsForbidden()
    {
        var (db, _, _, ev, _) = await Arrange();
        using var _db = db;
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new ResultsController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.Record(ev.Id, Req());

        Assert.IsType<ForbidResult>(result);
        Assert.Empty(db.Results);
    }

    [Fact]
    public async Task Record_UnknownBibNumber_Returns404()
    {
        var (db, org, _, ev, _) = await Arrange();
        using var _db = db;
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Record(ev.Id, Req(bib: 9999));

        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task Record_UnknownEvent_Returns404()
    {
        var (db, org, _, _, _) = await Arrange();
        using var _db = db;
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);

        Assert.IsType<NotFoundObjectResult>(await controller.Record(999, Req()));
    }

    [Fact]
    public async Task Record_SameParticipantTwice_Returns409()
    {
        var (db, org, _, ev, _) = await Arrange();
        using var _db = db;
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);
        await controller.Record(ev.Id, Req(position: 1));

        var result = await controller.Record(ev.Id, Req(position: 2));

        Assert.IsType<ConflictObjectResult>(result);
        Assert.Equal(1, await db.Results.CountAsync());
    }

    [Fact]
    public async Task Record_PositionAlreadyTaken_Returns409()
    {
        var (db, org, _, ev, _) = await Arrange();
        using var _db = db;
        var second = await TestHelpers.AddUser(db, UserRole.Participant);
        var cat = await db.Categories.FirstAsync();
        await TestHelpers.AddEnrolment(db, second.Id, ev.Id, cat.Id, 1002);
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);
        await controller.Record(ev.Id, Req(bib: 1001, position: 1));

        var result = await controller.Record(ev.Id, Req(bib: 1002, position: 1));

        Assert.IsType<ConflictObjectResult>(result);
    }

    [Fact]
    public async Task Record_ZeroFinishTime_Returns400()
    {
        var (db, org, _, ev, _) = await Arrange();
        using var _db = db;
        var controller = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Record(ev.Id, Req(time: "00:00:00"));

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task GetForEvent_ReturnsLeaderboard_OrderedByPosition()
    {
        var (db, org, _, ev, _) = await Arrange();
        using var _db = db;
        var second = await TestHelpers.AddUser(db, UserRole.Participant);
        var cat = await db.Categories.FirstAsync();
        await TestHelpers.AddEnrolment(db, second.Id, ev.Id, cat.Id, 1002);
        var organiser = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);
        await organiser.Record(ev.Id, Req(bib: 1001, time: "03:10:00", position: 2));
        await organiser.Record(ev.Id, Req(bib: 1002, time: "02:50:00", position: 1));

        var result = await new ResultsController(db).GetForEvent(ev.Id);

        var list = Assert.IsAssignableFrom<IEnumerable<ResultResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value).ToList();
        Assert.Equal(new[] { 1, 2 }, list.Select(r => r.Position));
        Assert.Equal(1002, list[0].BibNumber);
    }

    [Fact]
    public async Task GetForEvent_UnknownEvent_Returns404()
    {
        using var db = TestHelpers.NewDb();

        var result = await new ResultsController(db).GetForEvent(123);

        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetMine_ParticipantSeesOnlyTheirOwnResults()
    {
        var (db, org, runner, ev, _) = await Arrange();
        using var _db = db;
        var other = await TestHelpers.AddUser(db, UserRole.Participant);
        var cat = await db.Categories.FirstAsync();
        await TestHelpers.AddEnrolment(db, other.Id, ev.Id, cat.Id, 1002);
        var organiser = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);
        await organiser.Record(ev.Id, Req(bib: 1001, position: 1));
        await organiser.Record(ev.Id, Req(bib: 1002, position: 2));

        var result = await new ResultsController(db).WithUser(runner.Id, UserRole.Participant).GetMine();

        var list = Assert.IsAssignableFrom<IEnumerable<ResultResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value).ToList();
        Assert.Single(list);
        Assert.Equal(1001, list[0].BibNumber);
    }
}
