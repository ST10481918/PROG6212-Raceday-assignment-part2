using RaceDay.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

public class EnrolmentsControllerTests
{
    private static async Task<(AppDbContext Db, User Organiser, User Runner, Event Event, Category Category)> Arrange()
    {
        var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        return (db, org, runner, ev, cat);
    }

    [Fact]
    public async Task Enrol_Participant_RecordsLinkBetweenParticipantEventAndCategory()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        var obj = Assert.IsType<ObjectResult>(result);
        Assert.Equal(201, obj.StatusCode);
        var saved = await db.Enrolments.SingleAsync();
        Assert.Equal(runner.Id, saved.UserId);
        Assert.Equal(ev.Id, saved.EventId);
        Assert.Equal(cat.Id, saved.CategoryId);
    }

    [Fact]
    public async Task Enrol_AssignsBibNumber_AndReturnsIt()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        var body = Assert.IsType<EnrolResponse>(Assert.IsType<ObjectResult>(result).Value);
        Assert.Equal(1001, body.BibNumber);
        Assert.Equal(1001, (await db.Enrolments.SingleAsync()).BibNumber);
    }

    [Fact]
    public async Task Enrol_SecondParticipant_GetsNextBibNumber()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var second = await TestHelpers.AddUser(db, UserRole.Participant);
        await new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant)
            .Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        var result = await new EnrolmentsController(db).WithUser(second.Id, UserRole.Participant)
            .Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        var body = Assert.IsType<EnrolResponse>(Assert.IsType<ObjectResult>(result).Value);
        Assert.Equal(1002, body.BibNumber);
    }

    [Fact]
    public async Task Enrol_TwiceInSameEvent_Returns409()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);
        await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        var result = await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        Assert.IsType<ConflictObjectResult>(result);
        Assert.Equal(1, await db.Enrolments.CountAsync());
    }

    [Fact]
    public async Task Enrol_WithCategoryFromAnotherEvent_Returns400()
    {
        var (db, org, runner, ev, _) = await Arrange();
        using var _db = db;
        var otherEvent = await TestHelpers.AddEvent(db, org.Id);
        var foreignCategory = await TestHelpers.AddCategory(db, otherEvent.Id, "Elsewhere");
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = foreignCategory.Id });

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Empty(db.Enrolments);
    }

    [Fact]
    public async Task Enrol_UnknownEvent_Returns404()
    {
        var (db, _, runner, _, cat) = await Arrange();
        using var _db = db;
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Enrol(999, new EnrolRequest { CategoryId = cat.Id });

        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task Enrol_PastEvent_Returns400()
    {
        var (db, org, runner, _, _) = await Arrange();
        using var _db = db;
        var pastEvent = await TestHelpers.AddEvent(db, org.Id, daysFromNow: -10);
        var cat = await TestHelpers.AddCategory(db, pastEvent.Id);
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Enrol(pastEvent.Id, new EnrolRequest { CategoryId = cat.Id });

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task Withdraw_RemovesOwnEnrolment()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id);
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.Withdraw(ev.Id);

        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(db.Enrolments);
    }

    [Fact]
    public async Task Withdraw_WhenNotEnrolled_Returns404()
    {
        var (db, _, runner, ev, _) = await Arrange();
        using var _db = db;
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        Assert.IsType<NotFoundObjectResult>(await controller.Withdraw(ev.Id));
    }

    [Fact]
    public async Task Withdraw_DoesNotRemoveSomeoneElsesEnrolment()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var other = await TestHelpers.AddUser(db, UserRole.Participant);
        await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id);
        var controller = new EnrolmentsController(db).WithUser(other.Id, UserRole.Participant);

        var result = await controller.Withdraw(ev.Id);

        Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(1, await db.Enrolments.CountAsync());
    }

    [Fact]
    public async Task GetForEvent_OwningOrganiser_SeesAllEnrolments()
    {
        var (db, org, runner, ev, cat) = await Arrange();
        using var _db = db;
        var second = await TestHelpers.AddUser(db, UserRole.Participant);
        await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id, 1001);
        await TestHelpers.AddEnrolment(db, second.Id, ev.Id, cat.Id, 1002);
        var controller = new EnrolmentsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.GetForEvent(ev.Id);

        var list = Assert.IsAssignableFrom<IEnumerable<EnrolmentResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.Equal(2, list.Count());
    }

    [Fact]
    public async Task GetForEvent_OtherOrganiser_IsForbidden()
    {
        var (db, _, _, ev, _) = await Arrange();
        using var _db = db;
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EnrolmentsController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.GetForEvent(ev.Id);

        Assert.IsType<ForbidResult>(result.Result);
    }

    [Fact]
    public async Task GetMine_ReturnsOnlyMyEnrolments()
    {
        var (db, _, runner, ev, cat) = await Arrange();
        using var _db = db;
        var other = await TestHelpers.AddUser(db, UserRole.Participant);
        await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id, 1001);
        await TestHelpers.AddEnrolment(db, other.Id, ev.Id, cat.Id, 1002);
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        var result = await controller.GetMine();

        var list = Assert.IsAssignableFrom<IEnumerable<EnrolmentResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value).ToList();
        Assert.Single(list);
        Assert.Equal(runner.Id, list[0].ParticipantId);
    }
}
