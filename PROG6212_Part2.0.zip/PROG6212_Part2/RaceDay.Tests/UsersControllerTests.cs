using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

public class UsersControllerTests
{
    [Theory]
    [InlineData(UserRole.Participant)]
    [InlineData(UserRole.Organiser)]
    public async Task GetProfile_ReturnsOwnProfile_ForBothRoles(UserRole role)
    {
        using var db = TestHelpers.NewDb();
        var user = await TestHelpers.AddUser(db, role);
        var controller = new UsersController(db).WithUser(user.Id, role);

        var result = await controller.GetProfile();

        var profile = Assert.IsType<ProfileResponse>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.Equal(user.Id, profile.Id);
        Assert.Equal(role.ToString(), profile.Role);
    }

    [Fact]
    public async Task GetProfile_DoesNotExposeThePasswordHash()
    {
        Assert.DoesNotContain(typeof(ProfileResponse).GetProperties(), p => p.Name.Contains("Password"));
        await Task.CompletedTask;
    }

    [Fact]
    public async Task UpdateProfile_ChangesOnlyTheFieldsSent()
    {
        using var db = TestHelpers.NewDb();
        var user = await TestHelpers.AddUser(db, UserRole.Participant);
        var controller = new UsersController(db).WithUser(user.Id, UserRole.Participant);

        var result = await controller.UpdateProfile(new UpdateProfileRequest { EmergencyContact = "555-1234" });

        Assert.IsType<OkObjectResult>(result);
        var saved = await db.Users.FindAsync(user.Id);
        Assert.Equal("555-1234", saved!.EmergencyContact);
        Assert.Equal("Participant", saved.Name);
    }

    [Fact]
    public async Task UpdateProfile_CannotChangeRoleOrEmail()
    {
        using var db = TestHelpers.NewDb();
        var user = await TestHelpers.AddUser(db, UserRole.Participant, "keep@test.com");
        var controller = new UsersController(db).WithUser(user.Id, UserRole.Participant);

        await controller.UpdateProfile(new UpdateProfileRequest { Name = "New" });

        var saved = await db.Users.FindAsync(user.Id);
        Assert.Equal("keep@test.com", saved!.Email);
        Assert.Equal(UserRole.Participant, saved.Role);
    }

    [Fact]
    public async Task UpdateProfile_OnlyAffectsTheLoggedInUser()
    {
        using var db = TestHelpers.NewDb();
        var me = await TestHelpers.AddUser(db, UserRole.Participant);
        var other = await TestHelpers.AddUser(db, UserRole.Participant);
        var controller = new UsersController(db).WithUser(me.Id, UserRole.Participant);

        await controller.UpdateProfile(new UpdateProfileRequest { Name = "Changed" });

        Assert.Equal("Changed", (await db.Users.FindAsync(me.Id))!.Name);
        Assert.Equal("Participant", (await db.Users.FindAsync(other.Id))!.Name);
    }
}
