namespace RaceDay.Api.Models;

/// <summary>Finish time and finishing position captured by an Organiser after the event.</summary>
public class RaceResult
{
    public int Id { get; set; }

    public int EnrolmentId { get; set; }
    public Enrolment Enrolment { get; set; } = null!;

    public TimeSpan FinishTime { get; set; }

    public int Position { get; set; }

    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}
