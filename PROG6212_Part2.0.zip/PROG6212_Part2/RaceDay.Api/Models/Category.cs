using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

/// <summary>An age or distance category that belongs to one event (e.g. "Under 20", "10km").</summary>
public class Category
{
    public int Id { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    public int EventId { get; set; }
    public Event Event { get; set; } = null!;

    public List<Enrolment> Enrolments { get; set; } = new();
}
