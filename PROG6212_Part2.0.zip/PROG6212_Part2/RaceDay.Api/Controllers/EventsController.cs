using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Race day events. Anyone can view them; only the Organiser who owns an event can change or delete it.</summary>
[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public EventsController(AppDbContext db) => _db = db;

    /// <summary>List all events, soonest first.</summary>
    /// <response code="200">A list of events.</response>
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<EventResponse>>> GetAll()
    {
        var events = await _db.Events.AsNoTracking().OrderBy(e => e.Date).ToListAsync();
        return Ok(events.Select(EventResponse.From));
    }

    /// <summary>Get one event by id.</summary>
    /// <response code="200">The event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> GetById(int id)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        return ev is null ? NotFound(new MessageResponse("Event not found")) : Ok(EventResponse.From(ev));
    }

    /// <summary>Create an event (Organiser only).</summary>
    /// <remarks>Expects name, description, date, location, distanceKm and type (Run, Walk or Cycle). The logged-in Organiser becomes the owner.</remarks>
    /// <response code="201">Event created.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant.</response>
    [HttpPost]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<EventResponse>> Create(EventRequest request)
    {
        var ev = new Event
        {
            Name = request.Name.Trim(),
            Description = request.Description,
            Date = request.Date,
            Location = request.Location.Trim(),
            DistanceKm = request.DistanceKm,
            Type = request.Type,
            OrganiserId = CurrentUserId
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = ev.Id }, EventResponse.From(ev));
    }

    /// <summary>Update an event (owning Organiser only).</summary>
    /// <response code="200">Event updated.</response>
    /// <response code="403">Participant, or an Organiser who does not own this event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> Update(int id, EventRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        ev.Name = request.Name.Trim();
        ev.Description = request.Description;
        ev.Date = request.Date;
        ev.Location = request.Location.Trim();
        ev.DistanceKm = request.DistanceKm;
        ev.Type = request.Type;

        await _db.SaveChangesAsync();
        return Ok(EventResponse.From(ev));
    }

    /// <summary>Delete an event (owning Organiser only). Its categories, enrolments and results are deleted too.</summary>
    /// <response code="200">Event deleted.</response>
    /// <response code="403">Participant, or an Organiser who does not own this event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();
        return Ok(new MessageResponse("Event deleted successfully"));
    }
}
