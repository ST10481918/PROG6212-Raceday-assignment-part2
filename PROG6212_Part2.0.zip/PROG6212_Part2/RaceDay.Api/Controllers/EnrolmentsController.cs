using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Event enrolment: Participants enter events, Organisers view who entered their events.</summary>
[Route("api")]
[Authorize]
public class EnrolmentsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public EnrolmentsController(AppDbContext db) => _db = db;

    /// <summary>Enter an event by choosing a category (Participant only).</summary>
    /// <remarks>Expects categoryId. The category must belong to this event. A unique bib number is generated for the participant.</remarks>
    /// <response code="201">Enrolled. Returns the bib number.</response>
    /// <response code="400">Category does not belong to the event, or the event has already taken place.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    /// <response code="404">No event with that id.</response>
    /// <response code="409">Already enrolled in this event.</response>
    [HttpPost("events/{eventId:int}/enrol")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(EnrolResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Enrol(int eventId, EnrolRequest request)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));

        if (ev.Date.Date < DateTime.UtcNow.Date)
            return BadRequest(new MessageResponse("Enrolment is closed: this event has already taken place"));

        if (!await _db.Categories.AnyAsync(c => c.Id == request.CategoryId && c.EventId == eventId))
            return BadRequest(new MessageResponse("The selected category does not belong to this event"));

        var userId = CurrentUserId;
        if (await _db.Enrolments.AnyAsync(e => e.EventId == eventId && e.UserId == userId))
            return Conflict(new MessageResponse("You are already enrolled in this event"));

        var lastBib = await _db.Enrolments.Where(e => e.EventId == eventId)
            .MaxAsync(e => (int?)e.BibNumber);

        var enrolment = new Enrolment
        {
            UserId = userId,
            EventId = eventId,
            CategoryId = request.CategoryId,
            BibNumber = (lastBib ?? 1000) + 1,
            EnrolledAt = DateTime.UtcNow
        };

        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, new EnrolResponse
        {
            Message = "Registered for race",
            EnrolmentId = enrolment.Id,
            BibNumber = enrolment.BibNumber
        });
    }

    /// <summary>Withdraw my entry from an event (Participant only).</summary>
    /// <response code="200">Entry withdrawn.</response>
    /// <response code="400">A result has already been recorded for this entry.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    /// <response code="404">You are not enrolled in this event.</response>
    [HttpDelete("events/{eventId:int}/enrol")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Withdraw(int eventId)
    {
        var userId = CurrentUserId;
        var enrolment = await _db.Enrolments
            .FirstOrDefaultAsync(e => e.EventId == eventId && e.UserId == userId);
        if (enrolment is null) return NotFound(new MessageResponse("You are not enrolled in this event"));

        if (await _db.Results.AnyAsync(r => r.EnrolmentId == enrolment.Id))
            return BadRequest(new MessageResponse("A result has already been recorded for this entry"));

        _db.Enrolments.Remove(enrolment);
        await _db.SaveChangesAsync();
        return Ok(new MessageResponse("Race entry withdrawn"));
    }

    /// <summary>List all enrolments for one of my events (owning Organiser only).</summary>
    /// <response code="200">The enrolments, ordered by bib number.</response>
    /// <response code="403">Participant, or an Organiser who does not own the event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpGet("events/{eventId:int}/enrolments")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<EnrolmentResponse>>> GetForEvent(int eventId)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        var items = await _db.Enrolments.AsNoTracking()
            .Where(e => e.EventId == eventId)
            .OrderBy(e => e.BibNumber)
            .Select(e => new EnrolmentResponse
            {
                EnrolmentId = e.Id,
                EventId = e.EventId,
                EventName = e.Event.Name,
                ParticipantId = e.UserId,
                ParticipantName = e.User.Name + " " + e.User.Surname,
                CategoryId = e.CategoryId,
                CategoryName = e.Category.Name,
                BibNumber = e.BibNumber,
                EnrolledAt = e.EnrolledAt
            })
            .ToListAsync();
        return Ok(items);
    }

    /// <summary>List the events I have entered (Participant only).</summary>
    /// <response code="200">My enrolments.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    [HttpGet("enrolments/me")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<EnrolmentResponse>>> GetMine()
    {
        var userId = CurrentUserId;
        var items = await _db.Enrolments.AsNoTracking()
            .Where(e => e.UserId == userId)
            .OrderBy(e => e.Event.Date)
            .Select(e => new EnrolmentResponse
            {
                EnrolmentId = e.Id,
                EventId = e.EventId,
                EventName = e.Event.Name,
                ParticipantId = e.UserId,
                ParticipantName = e.User.Name + " " + e.User.Surname,
                CategoryId = e.CategoryId,
                CategoryName = e.Category.Name,
                BibNumber = e.BibNumber,
                EnrolledAt = e.EnrolledAt
            })
            .ToListAsync();
        return Ok(items);
    }
}
