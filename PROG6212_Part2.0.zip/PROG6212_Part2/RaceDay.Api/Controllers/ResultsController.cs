using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Race results: Organisers capture finish times and positions, Participants view their own.</summary>
[Route("api")]
public class ResultsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public ResultsController(AppDbContext db) => _db = db;

    /// <summary>Get the leaderboard for an event, ordered by finishing position.</summary>
    /// <response code="200">The results.</response>
    /// <response code="404">No event with that id.</response>
    [HttpGet("events/{eventId:int}/results")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(IEnumerable<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<ResultResponse>>> GetForEvent(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.Id == eventId))
            return NotFound(new MessageResponse("Event not found"));

        var items = await _db.Results.AsNoTracking()
            .Where(r => r.Enrolment.EventId == eventId)
            .OrderBy(r => r.Position)
            .Select(r => new ResultResponse
            {
                EventId = eventId,
                EventName = r.Enrolment.Event.Name,
                Position = r.Position,
                BibNumber = r.Enrolment.BibNumber,
                ParticipantName = r.Enrolment.User.Name + " " + r.Enrolment.User.Surname,
                Category = r.Enrolment.Category.Name,
                FinishTime = r.FinishTime
            })
            .ToListAsync();
        return Ok(items);
    }

    /// <summary>Record a participant's finish time and position (owning Organiser only).</summary>
    /// <remarks>Expects bibNumber, finishTime (hh:mm:ss) and position. The bib must belong to an enrolment in this event.</remarks>
    /// <response code="201">Result recorded.</response>
    /// <response code="400">Finish time must be greater than zero.</response>
    /// <response code="403">Participant, or an Organiser who does not own the event.</response>
    /// <response code="404">Event or bib number not found.</response>
    /// <response code="409">That participant already has a result, or the position is already taken.</response>
    [HttpPost("events/{eventId:int}/results")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Record(int eventId, RecordResultRequest request)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        if (request.FinishTime <= TimeSpan.Zero)
            return BadRequest(new MessageResponse("Finish time must be greater than zero"));

        var enrolment = await _db.Enrolments
            .FirstOrDefaultAsync(e => e.EventId == eventId && e.BibNumber == request.BibNumber);
        if (enrolment is null)
            return NotFound(new MessageResponse("No participant with that bib number in this event"));

        if (await _db.Results.AnyAsync(r => r.EnrolmentId == enrolment.Id))
            return Conflict(new MessageResponse("A result has already been recorded for this participant"));

        if (await _db.Results.AnyAsync(r => r.Enrolment.EventId == eventId && r.Position == request.Position))
            return Conflict(new MessageResponse("That finishing position is already taken"));

        _db.Results.Add(new RaceResult
        {
            EnrolmentId = enrolment.Id,
            FinishTime = request.FinishTime,
            Position = request.Position,
            RecordedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, new MessageResponse("Result logged successfully"));
    }

    /// <summary>View my own results across all events (Participant only).</summary>
    /// <response code="200">My results.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    [HttpGet("results/me")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(IEnumerable<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<ResultResponse>>> GetMine()
    {
        var userId = CurrentUserId;
        var items = await _db.Results.AsNoTracking()
            .Where(r => r.Enrolment.UserId == userId)
            .OrderBy(r => r.Enrolment.Event.Date)
            .Select(r => new ResultResponse
            {
                EventId = r.Enrolment.EventId,
                EventName = r.Enrolment.Event.Name,
                Position = r.Position,
                BibNumber = r.Enrolment.BibNumber,
                ParticipantName = r.Enrolment.User.Name + " " + r.Enrolment.User.Surname,
                Category = r.Enrolment.Category.Name,
                FinishTime = r.FinishTime
            })
            .ToListAsync();
        return Ok(items);
    }
}
