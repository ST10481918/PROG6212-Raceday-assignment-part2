using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;

public class EnrolRequest
{
    [Required] public int CategoryId { get; set; }
}

public class EnrolResponse
{
    public string Message { get; set; } = string.Empty;
    public int EnrolmentId { get; set; }
    public int BibNumber { get; set; }
}

public class EnrolmentResponse
{
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int BibNumber { get; set; }
    public DateTime EnrolledAt { get; set; }
}
