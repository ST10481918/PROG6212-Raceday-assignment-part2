using System.ComponentModel.DataAnnotations;
using RaceDay.Api.Models;

namespace RaceDay.Api.DTOs;

public class MessageResponse
{
    public string Message { get; set; } = string.Empty;
    public MessageResponse() { }
    public MessageResponse(string message) => Message = message;
}

public class RegisterRequest
{
    [Required, MaxLength(100)] public string Name { get; set; } = string.Empty;
    [Required, MaxLength(100)] public string Surname { get; set; } = string.Empty;
    [Required, EmailAddress, MaxLength(200)] public string Email { get; set; } = string.Empty;
    [Required, MinLength(8), MaxLength(100)] public string Password { get; set; } = string.Empty;

    /// <summary>Participant (default) or Organiser.</summary>
    public UserRole Role { get; set; } = UserRole.Participant;

    /// <summary>Secret invite code. Required only when Role is Organiser.</summary>
    public string? OrganiserCode { get; set; }

    [MaxLength(50)] public string? EmergencyContact { get; set; }
    public DateTime? DateOfBirth { get; set; }
}

public class LoginRequest
{
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public class LoginResponse
{
    public string Token { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
}
