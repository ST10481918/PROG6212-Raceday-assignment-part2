using System.ComponentModel.DataAnnotations;
using RaceDay.Api.Models;

namespace RaceDay.Api.DTOs;

public class EventRequest
{
    [Required, MaxLength(150)] public string Name { get; set; } = string.Empty;
    [MaxLength(2000)] public string Description { get; set; } = string.Empty;
    [Required] public DateTime Date { get; set; }
    [Required, MaxLength(200)] public string Location { get; set; } = string.Empty;
    [Range(0.1, 1000)] public double DistanceKm { get; set; }
    public EventType Type { get; set; }
}

public class EventResponse
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string Location { get; set; } = string.Empty;
    public double DistanceKm { get; set; }
    public EventType Type { get; set; }
    public int OrganiserId { get; set; }

    public static EventResponse From(Event e) => new()
    {
        Id = e.Id,
        Name = e.Name,
        Description = e.Description,
        Date = e.Date,
        Location = e.Location,
        DistanceKm = e.DistanceKm,
        Type = e.Type,
        OrganiserId = e.OrganiserId
    };
}
