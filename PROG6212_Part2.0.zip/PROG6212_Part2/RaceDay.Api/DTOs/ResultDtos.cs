using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;

public class RecordResultRequest
{
    /// <summary>Bib number of the participant in this event.</summary>
    [Required] public int BibNumber { get; set; }

    /// <summary>Finish time as hh:mm:ss, e.g. "02:45:12".</summary>
    [Required] public TimeSpan FinishTime { get; set; }

    /// <summary>Overall finishing position (1 = winner).</summary>
    [Range(1, 100000)] public int Position { get; set; }
}

public class ResultResponse
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public int Position { get; set; }
    public int BibNumber { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public TimeSpan FinishTime { get; set; }
}
